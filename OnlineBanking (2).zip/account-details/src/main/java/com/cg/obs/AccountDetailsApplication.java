package com.cg.obs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountDetailsApplication.class, args);
	}

}
