/**
 * 
 */
package com.cg.obs.model;

/**
 * @author sohel
 *
 */
public class Account {
	
}
