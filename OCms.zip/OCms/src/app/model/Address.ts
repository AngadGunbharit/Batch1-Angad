export class Addresss{
    address_id:number;
    area:string;
    city:string;
    pinCode:string; 
    state:string;
}