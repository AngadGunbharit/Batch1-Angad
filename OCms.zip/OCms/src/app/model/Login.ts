export class Login{
    userId:number;
    userName:string;
    password:string;
    role:string;   
}