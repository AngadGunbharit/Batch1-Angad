import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basichome',
  templateUrl: './basichome.component.html',
  styleUrls: ['./basichome.component.css']
})
export class BasichomeComponent implements OnInit {
  sidenavwidth:Number;
  mainwidth:Number;
  sidenavmargin:Number;
  mainmargin:Number;

  constructor() { }

  ngOnInit(): void {
    this.mainmargin=250;
    this.sidenavwidth=250;
  }
  openNav(){
    this.mainmargin=250;
    this.sidenavwidth=250;
  }

  closeNav(){
    this.mainmargin=0;
    this.sidenavwidth=0;
  }
}
