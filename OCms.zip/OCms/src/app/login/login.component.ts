import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Login } from '../model/Login';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName:string;
  password:string;
  role:string;
  showErrorMessage: boolean =false;

  constructor(private loginService:LoginService,private router:Router) { }

  loginForm=new FormGroup({
    uid:new FormControl('',[Validators.required]),
    pass:new FormControl('',[Validators.required])
  })

  ngOnInit(): void {}

  validate(){
    let tmpEmp:Login=new Login();
    this.loginService.findUserByUsername(this.userName,this.password).subscribe(
      data =>{
        if(data==null){
          alert('login failed');
        }
        sessionStorage.setItem("userId",data.userId);
        sessionStorage.setItem('user',this.userName);
        sessionStorage.setItem('role',this.role);

        if("customer"=== data.role.toLowerCase()) this.router.navigate(['/customer']);
        else if("owner" === data.role.toLowerCase()) this.router.navigate(['/restaurant-owner']);
     // else if("participant" === data.role.toLowerCase()) this.router.navigate(['/participant/givefeedback']);
      });
    
  }

}
